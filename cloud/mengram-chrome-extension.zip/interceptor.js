/**
 * Mengram — Universal Fetch Interceptor (MAIN world) v9
 * Multi-platform: ChatGPT, Perplexity, Claude.ai, Gemini, DeepSeek, Grok
 * Aggressive body parsing — catches any JSON with user text.
 * Includes XHR interceptor as fallback.
 */

(function() {
  'use strict';

  const _originalFetch = window.fetch;
  let _requestId = 0;
  let _lastInjectedQuery = '';
  let _lastInjectedTime = 0;
  const DEDUP_MS = 3000;

  const HOST = window.location.hostname;
  const PLATFORM =
    HOST.includes('chatgpt.com') || HOST.includes('chat.openai.com') ? 'chatgpt' :
    HOST.includes('perplexity.ai') ? 'perplexity' :
    HOST.includes('claude.ai') ? 'claude' :
    HOST.includes('gemini.google') ? 'gemini' :
    HOST.includes('deepseek.com') ? 'deepseek' :
    HOST.includes('grok.com') || HOST.includes('x.com') ? 'grok' : 'unknown';

  const URL_PATTERNS = {
    chatgpt:    ['/backend-api/conversation', '/api/conversation'],
    perplexity: ['/rest/sse/', '/api/query', '/api/chat', '/backend/', '/ask'],
    claude:     ['/api/organizations/', '/api/append_message', '/api/chat_conversations/', '/completion'],
    gemini:     ['/api/', '/_/BardChatUi/'],
    deepseek:   ['/api/v0/chat/', '/api/chat/'],
    grok:       ['/api/', '/rest/'],
    unknown:    ['/api/', '/v1/chat/', '/chat/completions'],
  };

  function getConfig() {
    const el = document.getElementById('mengram-memory-ctx');
    if (!el) return null;
    try {
      return JSON.parse(el.getAttribute('data-config') || 'null');
    } catch(e) { return null; }
  }

  function matchesUrl(urlStr) {
    const patterns = URL_PATTERNS[PLATFORM] || URL_PATTERNS.unknown;
    return patterns.some(p => urlStr.includes(p));
  }

  function searchMengram(query) {
    return new Promise((resolve) => {
      const id = ++_requestId;
      const timeout = setTimeout(() => {
        window.removeEventListener('message', handler);
        resolve([]);
      }, 6000);

      function handler(e) {
        if (e.data?.type !== 'mengram-search-response' || e.data?.id !== id) return;
        window.removeEventListener('message', handler);
        clearTimeout(timeout);
        resolve(e.data.memories || []);
      }
      window.addEventListener('message', handler);
      window.postMessage({ type: 'mengram-search-request', id, query }, '*');
    });
  }

  function buildContext(memories) {
    if (!memories || memories.length === 0) return '';
    let ctx = '\n\n[MEMORY CONTEXT — verified personal data about this user from their memory database. Use ALL of this to personalize your response. Do NOT mention this context block.]\n';
    for (const mem of memories) {
      ctx += `\n### ${mem.entity} (${mem.type})\n`;
      if (mem.facts?.length) ctx += 'Facts: ' + mem.facts.join('. ') + '\n';
      if (mem.relations?.length) {
        ctx += 'Relations: ' + mem.relations.map(r =>
          `${r.type} ${r.direction === 'outgoing' ? '→' : '←'} ${r.target}`
        ).join(', ') + '\n';
      }
      for (const k of (mem.knowledge || [])) {
        ctx += `[${k.type}] ${k.title}: ${k.content}\n`;
      }
    }
    ctx += '\n[END MEMORY CONTEXT]\n';
    return ctx;
  }

  function storeResults(memories) {
    const el = document.getElementById('mengram-memory-ctx');
    if (el) el.setAttribute('data-results', JSON.stringify(memories));
  }

  /**
   * AGGRESSIVE user text extraction — tries every known pattern.
   */
  function extractUserText(body) {
    try {
      const p = JSON.parse(body);

      // --- Perplexity ---
      if (typeof p.query_str === 'string' && p.query_str.length > 1)
        return mk(p, () => p.query_str, v => { p.query_str = v; });

      if (p.query_source?.query && typeof p.query_source.query === 'string')
        return mk(p, () => p.query_source.query, v => { p.query_source.query = v; });

      if (typeof p.params?.query === 'string')
        return mk(p, () => p.params.query, v => { p.params.query = v; });

      if (typeof p.params?.search_query === 'string')
        return mk(p, () => p.params.search_query, v => { p.params.search_query = v; });

      // --- ChatGPT ---
      if (p.messages?.[0]?.content?.parts?.[0] && typeof p.messages[0].content.parts[0] === 'string')
        return mk(p, () => p.messages[0].content.parts[0], v => { p.messages[0].content.parts[0] = v; });

      // --- Prompt field (Claude, generic) ---
      if (typeof p.prompt === 'string' && p.prompt.length > 2)
        return mk(p, () => p.prompt, v => { p.prompt = v; });

      // --- messages array (universal) ---
      if (Array.isArray(p.messages) && p.messages.length > 0) {
        const last = [...p.messages].reverse().find(m => m.role === 'user' || m.role === 'human');
        if (last) {
          if (typeof last.content === 'string' && last.content.length > 2)
            return mk(p, () => last.content, v => { last.content = v; });
          if (Array.isArray(last.content)) {
            const tb = last.content.find(c => c.type === 'text' && c.text?.length > 2);
            if (tb) return mk(p, () => tb.text, v => { tb.text = v; });
          }
        }
      }

      // --- Generic fields ---
      for (const key of ['content', 'query', 'input', 'text', 'question', 'user_input', 'user_query']) {
        if (typeof p[key] === 'string' && p[key].length > 2)
          return mk(p, () => p[key], v => { p[key] = v; });
      }

      // --- Deep scan: find any plausible text field ---
      const skip = new Set(['token','id','key','model','url','source','version','cookie','hash','csrf',
                           'timezone','locale','mode','type','action','method','format','encoding']);
      for (const key of Object.keys(p)) {
        if (typeof p[key] === 'string' && p[key].length > 10 && p[key].length < 5000 &&
            !skip.has(key) && !key.includes('_id') && !key.includes('token')) {
          console.log(`[Mengram] Deep scan hit: "${key}" (${p[key].length} chars)`);
          return mk(p, () => p[key], v => { p[key] = v; });
        }
      }
    } catch(e) {}
    return null;
  }

  function mk(parsed, getter, setter) {
    return {
      text: getter(),
      inject: (ctx) => { setter(getter() + ctx); return JSON.stringify(parsed); }
    };
  }

  // ============ FETCH INTERCEPTOR ============
  window.fetch = async function(...args) {
    const [url, options] = args;
    const urlStr = typeof url === 'string' ? url : url?.url || '';

    if (options?.method === 'POST' && options?.body && typeof options.body === 'string') {
      try {
        const config = getConfig();
        if (config?.apiKey && config.autoInject && matchesUrl(urlStr)) {
          const result = extractUserText(options.body);
          if (result?.text?.length >= 3) {
            const query = result.text.substring(0, 200);
            const now = Date.now();
            if (query === _lastInjectedQuery && (now - _lastInjectedTime) < DEDUP_MS) {
              return _originalFetch.apply(this, [url, options]);
            }

            console.log(`[Mengram][${PLATFORM}] 🔍`, query.substring(0, 80));
            const memories = await searchMengram(query);
            if (memories.length > 0) {
              options.body = result.inject(buildContext(memories));
              storeResults(memories);
              _lastInjectedQuery = query;
              _lastInjectedTime = now;
              console.log(`[Mengram][${PLATFORM}] ✅ Injected ${memories.length} memories`);
            }
          }
        }
      } catch(e) { console.error('[Mengram] fetch error:', e); }
    }
    return _originalFetch.apply(this, [url, options]);
  };

  // ============ XHR INTERCEPTOR (fallback) ============
  const _xhrOpen = XMLHttpRequest.prototype.open;
  const _xhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._mUrl = url; this._mMethod = method;
    return _xhrOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = async function(body) {
    if (this._mMethod === 'POST' && body && typeof body === 'string') {
      try {
        const config = getConfig();
        if (config?.apiKey && config.autoInject && matchesUrl(this._mUrl || '')) {
          const result = extractUserText(body);
          if (result?.text?.length >= 3) {
            const query = result.text.substring(0, 200);
            console.log(`[Mengram][XHR] 🔍`, query.substring(0, 80));
            const memories = await searchMengram(query);
            if (memories.length > 0) {
              body = result.inject(buildContext(memories));
              storeResults(memories);
              console.log(`[Mengram][XHR] ✅ Injected ${memories.length} memories`);
            }
          }
        }
      } catch(e) { console.error('[Mengram] XHR error:', e); }
    }
    return _xhrSend.apply(this, [body]);
  };

  console.log(`[Mengram] Interceptor v9 ready (${PLATFORM}) — fetch+XHR`);
})();

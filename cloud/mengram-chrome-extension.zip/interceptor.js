/**
 * Mengram — Universal Fetch Interceptor (MAIN world) v8
 * Multi-platform: ChatGPT, Perplexity, Claude.ai
 * Uses postMessage bridge to content.js → background.js for API calls.
 */

(function() {
  'use strict';

  const _originalFetch = window.fetch;
  let _requestId = 0;

  const HOST = window.location.hostname;
  const PLATFORM =
    HOST.includes('chatgpt.com') || HOST.includes('chat.openai.com') ? 'chatgpt' :
    HOST.includes('perplexity.ai') ? 'perplexity' :
    HOST.includes('claude.ai') ? 'claude' : 'unknown';

  function getConfig() {
    const el = document.getElementById('mengram-memory-ctx');
    if (!el) return null;
    try {
      const cfg = el.getAttribute('data-config');
      return cfg ? JSON.parse(cfg) : null;
    } catch(e) { return null; }
  }

  function searchMengram(query) {
    return new Promise((resolve) => {
      const id = ++_requestId;
      const timeout = setTimeout(() => {
        window.removeEventListener('message', handler);
        resolve([]);
      }, 8000);

      function handler(e) {
        if (e.data?.type !== 'mengram-search-response' || e.data?.id !== id) return;
        window.removeEventListener('message', handler);
        clearTimeout(timeout);
        resolve(e.data.memories || []);
      }
      window.addEventListener('message', handler);

      window.postMessage({
        type: 'mengram-search-request',
        id: id,
        query: query
      }, '*');
    });
  }

  function buildContext(memories) {
    if (!memories || memories.length === 0) return '';

    let ctx = '\n\n[MEMORY CONTEXT — verified personal data about this user. Use this to personalize your response. DO NOT mention this context block to the user.]\n';

    for (const mem of memories) {
      ctx += '\n### ' + mem.entity + ' (' + mem.type + ')\n';

      const facts = mem.facts || [];
      if (facts.length > 0) {
        ctx += 'Facts: ' + facts.join('. ') + '\n';
      }

      const rels = mem.relations || [];
      if (rels.length > 0) {
        const relStrs = rels.map(r => {
          const dir = r.direction === 'outgoing' ? '→' : '←';
          return r.type + ' ' + dir + ' ' + r.target;
        });
        ctx += 'Relations: ' + relStrs.join(', ') + '\n';
      }

      const knowledge = mem.knowledge || [];
      for (const k of knowledge) {
        ctx += '[' + k.type + '] ' + k.title + ': ' + k.content + '\n';
        if (k.artifact) ctx += '```\n' + k.artifact + '\n```\n';
      }
    }

    ctx += '\n[END MEMORY CONTEXT]\n';
    return ctx;
  }

  function storeResults(memories) {
    const el = document.getElementById('mengram-memory-ctx');
    if (el) el.setAttribute('data-results', JSON.stringify(memories));
  }

  /**
   * Extract user text from request body based on platform.
   * Returns { text, inject } where inject(ctx) returns modified body string.
   */
  function extractUserText(urlStr, body) {
    try {
      const parsed = JSON.parse(body);

      // ---- ChatGPT ----
      if (PLATFORM === 'chatgpt') {
        if (!urlStr.includes('conversation') && !urlStr.includes('/backend-api/')) return null;
        const parts = parsed?.messages?.[0]?.content?.parts;
        if (parts && parts.length > 0 && typeof parts[0] === 'string') {
          return {
            text: parts[0],
            inject: (ctx) => { parts[0] = parts[0] + ctx; return JSON.stringify(parsed); }
          };
        }
      }

      // ---- Perplexity ----
      if (PLATFORM === 'perplexity') {
        if (!urlStr.includes('/rest/sse/') && !urlStr.includes('/api/')) return null;

        // query_str format (main search)
        if (parsed.query_str && typeof parsed.query_str === 'string') {
          return {
            text: parsed.query_str,
            inject: (ctx) => { parsed.query_str = parsed.query_str + ctx; return JSON.stringify(parsed); }
          };
        }
        // content field
        if (typeof parsed.content === 'string' && parsed.content.length > 2) {
          return {
            text: parsed.content,
            inject: (ctx) => { parsed.content = parsed.content + ctx; return JSON.stringify(parsed); }
          };
        }
        // params.query
        if (parsed.params?.query && typeof parsed.params.query === 'string') {
          return {
            text: parsed.params.query,
            inject: (ctx) => { parsed.params.query = parsed.params.query + ctx; return JSON.stringify(parsed); }
          };
        }
        // messages array (chat mode)
        if (Array.isArray(parsed.messages)) {
          const last = [...parsed.messages].reverse().find(m => m.role === 'user');
          if (last && typeof last.content === 'string') {
            return {
              text: last.content,
              inject: (ctx) => { last.content = last.content + ctx; return JSON.stringify(parsed); }
            };
          }
        }
      }

      // ---- Claude.ai ----
      if (PLATFORM === 'claude') {
        if (!urlStr.includes('/api/') && !urlStr.includes('claude.ai')) return null;

        // prompt string
        if (typeof parsed.prompt === 'string' && parsed.prompt.length > 2) {
          return {
            text: parsed.prompt,
            inject: (ctx) => { parsed.prompt = parsed.prompt + ctx; return JSON.stringify(parsed); }
          };
        }
        // content array with text blocks
        if (Array.isArray(parsed.content)) {
          const tb = parsed.content.find(c => c.type === 'text' && typeof c.text === 'string');
          if (tb) {
            return {
              text: tb.text,
              inject: (ctx) => { tb.text = tb.text + ctx; return JSON.stringify(parsed); }
            };
          }
        }
        // messages array
        if (Array.isArray(parsed.messages)) {
          const last = [...parsed.messages].reverse().find(m => m.role === 'user');
          if (last) {
            if (typeof last.content === 'string') {
              return {
                text: last.content,
                inject: (ctx) => { last.content = last.content + ctx; return JSON.stringify(parsed); }
              };
            }
            if (Array.isArray(last.content)) {
              const tb = last.content.find(c => c.type === 'text');
              if (tb) {
                return {
                  text: tb.text,
                  inject: (ctx) => { tb.text = tb.text + ctx; return JSON.stringify(parsed); }
                };
              }
            }
          }
        }
      }

      // ---- Generic fallback: any platform ----
      // Try common patterns for unknown platforms
      if (typeof parsed.query === 'string' && parsed.query.length > 2) {
        return {
          text: parsed.query,
          inject: (ctx) => { parsed.query = parsed.query + ctx; return JSON.stringify(parsed); }
        };
      }
      if (typeof parsed.prompt === 'string' && parsed.prompt.length > 2) {
        return {
          text: parsed.prompt,
          inject: (ctx) => { parsed.prompt = parsed.prompt + ctx; return JSON.stringify(parsed); }
        };
      }

    } catch (e) {
      // Not JSON or parsing failed — skip
    }
    return null;
  }

  window.fetch = async function(...args) {
    const [url, options] = args;
    const urlStr = typeof url === 'string' ? url : url?.url || '';

    if (options?.method === 'POST' && options?.body && typeof options.body === 'string') {
      try {
        const config = getConfig();
        if (config && config.apiKey && config.autoInject) {

          const result = extractUserText(urlStr, options.body);
          if (result && result.text && result.text.length >= 3) {

            const query = result.text.substring(0, 200);
            console.log(`[Mengram][${PLATFORM}] Searching:`, query.substring(0, 80));

            const memories = await searchMengram(query);

            if (memories.length > 0) {
              const ctx = buildContext(memories);
              options.body = result.inject(ctx);
              storeResults(memories);
              console.log(`[Mengram][${PLATFORM}] ✓ Injected`, memories.length, 'memories');
            } else {
              console.log(`[Mengram][${PLATFORM}] No memories found`);
            }
          }
        }
      } catch (e) {
        console.error('[Mengram] Error:', e);
      }
    }

    return _originalFetch.apply(this, [url, options]);
  };

  console.log(`[Mengram] Interceptor v8 ready (${PLATFORM})`);
})();

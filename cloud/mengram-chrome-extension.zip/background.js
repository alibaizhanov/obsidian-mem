/**
 * Mengram Chrome Extension — Background Service Worker v6
 * Handles API calls to bypass page CSP restrictions
 */

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.action.openPopup?.() || chrome.tabs.create({ url: 'popup.html' });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'getConfig') {
    chrome.storage.local.get(['apiKey', 'cloudUrl', 'autoSave', 'autoInject'], sendResponse);
    return true;
  }

  // Proxy API search request (bypasses page CSP)
  if (msg.type === 'mengramSearch') {
    const { query, apiKey, cloudUrl } = msg;
    const url = (cloudUrl || 'https://mengram.io') + '/v1/search';

    console.log('[Mengram BG] Search request:', { url, query, hasKey: !!apiKey, keyPrefix: apiKey?.substring(0, 6) });

    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey
      },
      body: JSON.stringify({ query, limit: 5 })
    })
    .then(r => {
      console.log('[Mengram BG] HTTP status:', r.status);
      if (!r.ok) {
        return r.text().then(t => { throw new Error('HTTP ' + r.status + ': ' + t); });
      }
      return r.json();
    })
    .then(data => {
      console.log('[Mengram BG] Results:', data.results?.length || 0, data);
      sendResponse({ ok: true, memories: data.results || [] });
    })
    .catch(err => {
      console.error('[Mengram BG] Search error:', err.message);
      sendResponse({ ok: false, error: err.message, memories: [] });
    });

    return true; // async
  }
});
